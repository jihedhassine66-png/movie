import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import '../index.css';
const MovieDetail = ({ movies }) => {
  const { title } = useParams();
  const navigate = useNavigate();
  
  // Trouve le film correspondant au titre
  const movie = movies.find(m => m.title === title);
  return (
    <div className="MovieDetail">
        <div  className="MovieDetail" style={{ padding: '40px', color: 'var(--text-main)', maxWidth: '900px', margin: '0 auto' }}>
            <Button variant="outline-light" onClick={() => navigate('/')} style={{ marginBottom: '20px' }}>
            ← Retour à l'accueil
            </Button>
            <h1 style={{ fontWeight: '800', marginBottom: '20px' }}>{movie.title}</h1>
            <p style={{ fontSize: '1.1rem', lineHeight: '1.6', color: 'var(--text-secondary)' }}>
            {movie.description}
            </p>
            <div style={{ marginTop: '40px', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 10px 30px rgba(0,0,0,0.5)' }}>
                <iframe 
                    width="100%" 
                    height="500" 
                    src={movie.trailerLink} 
                    title={`${movie.title} Trailer`}
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    referrerpolicy="strict-origin-when-cross-origin"
                    allowFullScreen
                ></iframe>
            </div>
        </div>
    </div>
  );
};

export default MovieDetail;